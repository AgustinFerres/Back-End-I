package com.example.proyecto_Integrador.repository;

import com.example.proyecto_Integrador.entity.Domicilio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DomicilioRepository extends JpaRepository<Domicilio, Long> {


}
