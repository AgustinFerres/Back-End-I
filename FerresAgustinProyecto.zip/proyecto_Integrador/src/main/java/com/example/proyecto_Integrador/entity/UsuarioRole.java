package com.example.proyecto_Integrador.entity;

public enum UsuarioRole {
    ROLE_USER, ROLE_ADMIN
}
