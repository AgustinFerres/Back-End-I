package com.example.proyecto_Integrador.repository;

import com.example.proyecto_Integrador.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Long> {
}
